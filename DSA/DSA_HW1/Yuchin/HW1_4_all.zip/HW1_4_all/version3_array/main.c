#include <stdio.h>

#define MAX_IN 1000000
#define MAX_STACK 100000

void computation(char *stack_c, double *stack_d, int *top_c, int *top_d);
char get_priority(char operator);

int main() {
    char input[MAX_IN];
    char stack_c[MAX_STACK];
    double stack_d[MAX_STACK];

    while (scanf("%s", input) != EOF){
        int top_c = -1, top_d = -1;

        for (int idx = 0; idx < MAX_IN && input[idx] != 0; idx++){
            // TODO 數字
            if (input[idx] >= '0' && input[idx] <= '9'){
                double temp = input[idx] - '0';
                while (input[idx + 1] >= '0' && input[idx + 1] <= '9'){
                    idx ++;
                    temp = 10 * temp + input[idx] - '0';
                }
                stack_d[++top_d] = temp;
            }
            // TODO 符號
            else{
                char operator = input[idx];
                switch (operator) {
                    case '(':
                        stack_c[++top_c] = operator;    // push
                        break;
                    case ')':
                        while (stack_c[top_c] != '('){  // seek
                            computation(stack_c, stack_d, &top_c, &top_d);
                        }
                        top_c --;   // pop
                        break;
                    case '+': case '-': case '*': case '/':
                        while (get_priority(stack_c[top_c]) >= get_priority(operator)){
                            computation(stack_c, stack_d, &top_c, &top_d);
                        }
                        stack_c[++top_c] = operator; // push
                        break;
                    default:
                        break;
                }
            }
        }

        while (top_c != -1){
            computation(stack_c, stack_d, &top_c, &top_d);
        }
        printf("%.12f\n", stack_d[0]);
    }
    return 0;
}


void computation(char *stack_c, double *stack_d, int *top_c, int *top_d) {
    char operator = stack_c[(*top_c) --];
    double num2 = stack_d[(*top_d) --];
    double num1 = stack_d[(*top_d) --];
    switch (operator) {
        case '+':
            stack_d[++ (*top_d)] = num1 + num2;
            break;
        case '-':
            stack_d[++ (*top_d)] = num1 - num2;
            break;
        case '*':
            stack_d[++ (*top_d)] = num1 * num2;
            break;
        case '/':
            stack_d[++ (*top_d)] = num1 / num2;
            break;
        default:
            break;
    }
}

char get_priority(char operator) {
    switch (operator) {
        case '+': case '-':
            return 1;
        case '*': case '/':
            return 2;
        default:
            return 0;
    }
}



