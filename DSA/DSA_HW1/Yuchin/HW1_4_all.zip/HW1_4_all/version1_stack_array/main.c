#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <assert.h>
#define MAX 1000000

#include "Stack.c"
#include "utils.c"

/* Stack 使用方法，{} 內的東西代表自訂：
 *
 * 1. create:
 *      Stack *{stack_name} = createStack({stack_type});
 *      stack_type in {STACK_CHAR, STACK_DOUBLE}，看要宣告什麼型態的 Stack
 *
 *      EX:
 *          Stack *stack_c = createStack(STACK_CHAR);
 *
 * 2. push:
 *      {type} *temp = {value};
 *      type in {char, double}，一樣看要宣告哪種型態
 *
 *      push({stack_name}, &temp);
 *      => 切記：
 *          (1) Temp 一定要傳 address
 *          (2) push function 內會將 temp 照 Stack 宣告的 type 強制轉型
 *
 *      EX:
 *          char *temp = 123;
 *          push(stack_c, &temp);
 *
 * 3. pop:
 *      pop({stack_name});
 *      pop 出來的值在： {stack_name} -> {pop_c / pop_d}
 *
 *      EX:
 *          pop(stack_c);
 *          char res = stack_c->pop_c;
 *
 * */

int main() {

    char input[MAX] = {0};

    while(scanf("%s", input) != EOF){
        Stack *stack_c = createStack(STACK_CHAR); // 符號用
        Stack *stack_d = createStack(STACK_DOUBLE); // 數字用

        int idx = 0;
        while(idx < MAX && input[idx] != 0){
            // TODO 數字處理
            if (input[idx] >= '0' && input[idx] <= '9'){
                double temp = input[idx] - '0';
                while (input[idx + 1] >= '0' && input[idx + 1] <= '9'){
                    temp = temp * 10 + input[idx] - '0';
                    idx ++;
                }
                push(stack_d, &temp);
            }

                // TODO 符號處理
            else{
                char oper = input[idx];
                switch (oper) {
                    case '(':
                        push(stack_c, &oper);
                        break;
                        // 清空到左括號為止
                    case ')': {
                        while (stack_c->arr_c[stack_c->top] != '('){
                            computation(stack_c, stack_d); // computation function 內會自動 pop
                        }
                        pop(stack_c); // pop 左括號
                        break;
                    }
                    case '+': case '-': case '*': case '/':
                        // 如果前一個優先權
                        while (get_priority(stack_c->arr_c[stack_c->top]) >= get_priority(oper)){
                            computation(stack_c, stack_d);
                        }
                        push(stack_c, &oper);
                        break;
                    default:
                        break;
                }
            }
            idx++;
        }

        while (! isEmpty(stack_c)) {
            computation(stack_c, stack_d);
        }
        printf("%.12f\n", stack_d->arr_d[stack_d->top]);
        freeStack(stack_c);
        freeStack(stack_d);
    }
    return 0;
}
