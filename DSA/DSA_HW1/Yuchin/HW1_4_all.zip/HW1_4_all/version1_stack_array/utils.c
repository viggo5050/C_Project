//
// Created by Yuwen Huang on 2021/3/26.
//

char get_priority(char oper){
    switch (oper) {
        case '+': case '-':
            return 1;
        case '*': case '/':
            return 2;
        default:
            return 0;
    }
}


// Computation 只有計算，判斷是否計算的邏輯寫在 main()
void computation(Stack *stack_c, Stack *stack_d){
    pop(stack_c);
    pop(stack_d);
    double num2 = stack_d->pop_d;
    pop(stack_d);
    double num1 = stack_d->pop_d;
    double res = 0;

    switch (stack_c->pop_c) {
        case '+':
            res = num1 + num2;
            break;
        case '-':
            res = num1 - num2;
            break;
        case '*':
            res = num1 * num2;
            break;
        case '/':
            res = num1 / num2;
            break;
        default:
            break;
    }
    push(stack_d, &res);
}


