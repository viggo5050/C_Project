//
// Created by Yuwen Huang on 2021/3/25.
//
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

enum stack_type {
    STACK_CHAR, STACK_DOUBLE
};

// define stack struct
typedef struct {
    int top;
    int capacity;
    char type;
    union {
        char *arr_c;
        double *arr_d;
    };
    union {
        char pop_c;
        double pop_d;
    };
} Stack;

Stack *createStack(const enum stack_type type) {
    Stack *S = malloc(sizeof(Stack));
    S->capacity = 1;
    S->top = -1;
    S->type = type;
    S->arr_c = (char *) malloc(S->capacity * sizeof(char));
    S->arr_d = (double *) malloc(S->capacity * sizeof(double));
    return S;
}

bool isFullStack(Stack *S) {
    return S->top == S->capacity - 1;
}

bool isEmpty(Stack *S){
    return S->top == -1;
}

void enlarge(Stack *S) {
    int new_capacity = S->capacity * 3;
    S->capacity = new_capacity;
    switch (S->type) {
        case STACK_CHAR:
            S->arr_c = (char *) realloc(S->arr_c, new_capacity * sizeof(char));
            break;
        case STACK_DOUBLE:
            S->arr_d = (double *) realloc(S->arr_d, new_capacity * sizeof(double));
            break;
        default:
            break;
    }
}

void push(Stack *S, void *data) {
    switch (S->type) {
        case STACK_CHAR:
            S->arr_c[++S->top] = *(char *) data;
            break;
        case STACK_DOUBLE:
            S->arr_d[++S->top] = *(double *) data;
            break;
        default:
            break;
    }
    if (isFullStack(S))
        enlarge(S);
}

void pop(Stack *S) {
    switch (S->type) {
        case STACK_CHAR:
            S->pop_c = S->arr_c[S->top--];
            break;
        case STACK_DOUBLE:
            S->pop_d = S->arr_d[S->top--];
            break;
        default:
            break;
    }
}

void printStack(Stack *S) {
    switch (S->type) {
        case STACK_CHAR:
            printf("Stack char: ");
            for(int i = 0; i <= S->top; i++) {
                printf("%c ", S->arr_c[i]);
            }
            break;
        case STACK_DOUBLE:
            printf("Stack double: ");
            for(int i = 0; i <= S->top; i++) {
                printf("%.12f ", S->arr_d[i]);
            }
            break;
        default:
            break;
    }
    printf("\n");
}


void freeStack(Stack *S){
    if (S->type == STACK_CHAR){
        free(S->arr_c);
    }
    else {
        free(S->arr_d);
    }
    free(S);
}
