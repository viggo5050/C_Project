#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX_IN 1000000


// char 與 double 共用同一個 Node type
typedef struct node{
    double val;
    struct node *next;
} Node;

Node *createNode(double val);
bool isEmpty(Node *root);
void push(Node *root, double val);
double pop(Node *root);
double seek(Node *root);
void traversal(Node *root);

void computation(Node *root_c, Node *root_d);
char get_priority(char operator);

int main() {

    char input[MAX_IN];
    while (scanf("%s", input) != EOF){
        Node *root_c = createNode(0);
        Node *root_d = createNode(0);
        int idx = 0;
        while (idx < MAX_IN && input[idx] != 0){
            // TODO 數字
            if (input[idx] >= '0' && input[idx] <= '9'){
                double temp = input[idx] - '0';  // 計算數字
                while (input[idx + 1] >= '0' && input[idx + 1] <= '9'){
                    idx ++;
                    temp = temp * 10 + input[idx] - '0';
                }
                push(root_d, temp);
            }
            // TODO 符號
            else {
                char operator = input[idx]; // 抓符號
                switch (operator) {
                    case '(':
                        push(root_c, operator);
                        break;
                    case ')':
                        while ((char)seek(root_c) != '('){
                            computation(root_c, root_d);
                        }
                        pop(root_c); // Pop 左括號
                        break;
                    case '+': case '-': case '*': case '/':
                        while (get_priority((char)seek(root_c)) >= get_priority(operator)){
                            computation(root_c, root_d);
                        }
                        push(root_c, operator);
                        break;
                    default:
                        break;
                }
            }
            idx ++;
        }

        // 把剩下的符號計算完
        while (! isEmpty(root_c)){
            computation(root_c, root_d);
        }

        // 輸出答案、釋放 malloc
        printf("%.12f\n", seek(root_d));
        free(root_c);
        free(root_d);
    }
    return 0;
}


Node *createNode(double val){
    Node *node = malloc(sizeof(Node));
    node->val = val;
    node->next = NULL;
    return node;
}

void push(Node *root, double val){
    Node *new_node = createNode(val);
    if (root->next){    // Linked List 內已經有東西
        Node *nextPtr = root->next;
        root->next = new_node;
        new_node->next = nextPtr;
    } else {    // Linked List 尚未有東西
        root->next = new_node;
    }
}

double pop(Node *root) {
    Node *nextPtr = root->next;
    double res = nextPtr->val;
    if(nextPtr->next){
        root->next = nextPtr->next;
    } else {
        root->next = NULL;
    }
    free(nextPtr);
    return res;
}

bool isEmpty(Node *root) {
    if (root->next) return false;
    else return true;
}

double seek(Node *root) {
    if (root->next) return root->next->val;
    else return -1;
}

void traversal(Node *root) {
    printf("Linked List traversal:\n");
    Node *dummy = root;
    while (dummy->next){
        printf("%f -> ", dummy->next->val);
        dummy = dummy->next;
    }
    printf("NULL\n");
}

void computation(Node *root_c, Node *root_d) {
    char operator = (char) pop(root_c);
    double num2 = pop(root_d);
    double num1 = pop(root_d);
    switch (operator) {
        case '+':
            push(root_d, num1 + num2);
            break;
        case '-':
            push(root_d, num1 - num2);
            break;
        case '*':
            push(root_d, num1 * num2);
            break;
        case '/':
            push(root_d, num1 / num2);
            break;
        default:
            break;
    }
}

char get_priority(char operator){
    switch (operator) {
        case '+': case '-':
            return 1;
        case '*': case '/':
            return 2;
        default:
            return 0;
    }
}



